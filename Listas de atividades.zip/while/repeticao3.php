<?php
	echo "numeros pares:<br>";
	for ($i=0; $i <= 50; $i += 2) { 
		print "$i, ";
	}
?>