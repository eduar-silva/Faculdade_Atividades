<?php
	for ($i=0; $i <= 10; $i++) { 
		$sq=$i**2;
		print "$i^2 = $sq<br>";
	}
?>