#include <stdio.h>

int main()
{
    int opcaosexo;
    float mediaParaAprovacao, media, nota1, nota2, nota3;
    char nome[20];
    
    //coleta de notas e cálculo da média
    printf("Digite a média de aprovação do seu curso/faculdade/escola: ");
    scanf("%f", &mediaParaAprovacao);
    printf("Digite sua primeira nota: ");
    scanf("%f", &nota1);
    printf("Digite sua segunda nota: ");
    scanf("%f", &nota2);
    printf("Digite sua terceira nota: ");
    scanf("%f", &nota3);
    media = (nota1+nota2+nota3)/3;
    
    //nome e sexo do aluno
    printf("Digite seu nome: ");
    scanf("%20s", nome);
    printf("Digite o número respectivo ao seu sexo\n 1. Masculino \n 2. Feminino\n");
    scanf("%d", &opcaosexo);
    
    switch (opcaosexo) {
        case 1: 
        if (media >= mediaParaAprovacao) {
            printf("O aluno %s foi aprovado com média %.2f", nome, media);
        } else {
            printf("Reprovado!!");
        }
        break;
        
        case 2:
        if (media >= mediaParaAprovacao) {
            printf("A aluna %s foi aprovada com média %.2f", nome, media);
        } else {
            printf("Reprovada!!");
        }
        break;
        default:
        printf("Fora do intervalo!!");
    }

    return 0;
}
