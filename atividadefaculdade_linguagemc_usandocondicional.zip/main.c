#include <stdio.h>
#include <ctype.h>

int main()
{
    float mediaParaAprovacao, media, nota1, nota2, nota3;
    char nome[20], letraSexo;
    
    //solicitação de dados do usuário
    printf("Digite a média para ser aprovado: ");
    scanf("%f", &mediaParaAprovacao);
    printf("Digite seu nome: ");
    scanf("%20s", nome);
    
    //convertendo letra para maiúscula
    printf("Para Masculino digite 'M' e para feminino digite 'F' \nDigite seu sexo: ");
    scanf("%9s", &letraSexo);
    char sexo = toupper(letraSexo);
    
    //solicitação de notas
    printf("Digite sua primeira nota: ");
    scanf("%f", &nota1);
    printf("Digite sua segunda nota: ");
    scanf("%f", &nota2);
    printf("Digite sua terceira nota: ");
    scanf("%f", &nota3);
    
    //cálculo da média
    media = (nota1 + nota2 + nota3)/3;
    
    //condicionais para aprovação
    if (media >= mediaParaAprovacao && sexo == 'M') {
        printf("O aluno %s foi aprovado com média %.2f", nome, media);
    } else if (media < mediaParaAprovacao && sexo == 'M') {
        printf("O aluno %s foi reprovado com média %.2f", nome, media);
    }
    
    if (media >= mediaParaAprovacao && sexo == 'F') {
        printf("A aluna %s foi aprovada com média %.2f", nome, media);
    } else if (media < mediaParaAprovacao && sexo == 'F') {
        printf("A aluna %s foi reprovada com média %.2f", nome, media);
    }

    return 0;
}
